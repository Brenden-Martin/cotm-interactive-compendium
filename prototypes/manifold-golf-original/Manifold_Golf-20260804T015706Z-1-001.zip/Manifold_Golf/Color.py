# Full 3D Torus Viewer with Tunable Geodesics
# Dependencies: pygame, numpy, PyOpenGL

import numpy as np
import pygame
from pygame.locals import DOUBLEBUF, OPENGL, QUIT
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import glutInit, glutSolidSphere
import random, math

# Torus parameters
R, r = 2.5, 1.0
res_u, res_v = 100, 50
u = np.linspace(0, 2*math.pi, res_u)
v = np.linspace(0, 2*math.pi, res_v)

# Physics tuning
deflection_scale = -0.5   # Strength of perpendicular bump deflection
brake_scale      = 0.05   # Strength of uphill braking from bumps
drag             = 0.995  # Velocity damping factor (0 < drag <= 1)
dt               = 0.02   # Simulation time step
stop_thresh      = 0.01   # Velocity threshold to stop ball
max_speed        = 5.0
max_accel        = 20.0
ball_offset      = 0.03   # Visual offset for ball/hole/trail

# Bump mapping
bump_hills = []

def generate_bump_hills(n, max_h=0.6, sigma=0.3):
    global bump_hills
    bump_hills = [(
        random.uniform(0, 2*math.pi), random.uniform(0, 2*math.pi),
        random.uniform(0, max_h), sigma
    ) for _ in range(n)]

def bump_height(u_val, v_val):
    h = 0.0
    for u0, v0, A, s in bump_hills:
        du = min(abs(u_val - u0), 2*math.pi - abs(u_val - u0))
        dv = min(abs(v_val - v0), 2*math.pi - abs(v_val - v0))
        h += A * math.exp(-(du*du + dv*dv) / (2 * s * s))
    return h

# Torus coordinate helpers
def torus_coords(u_val, v_val):
    return np.array([
        (R + r * math.cos(v_val)) * math.cos(u_val),
        (R + r * math.cos(v_val)) * math.sin(u_val),
        r * math.sin(v_val)
    ])

def torus_point_bumped(u_val, v_val):
    base = torus_coords(u_val, v_val)
    nx, ny, nz = math.cos(v_val)*math.cos(u_val), math.cos(v_val)*math.sin(u_val), math.sin(v_val)
    pos = base + bump_height(u_val, v_val) * np.array([nx, ny, nz])
    norm = np.array([nx, ny, nz])
    norm /= np.linalg.norm(norm)
    return pos, norm

# Precompute analytic torus metric and derivatives
du = u[1] - u[0]
dv = v[1] - v[0]

u_grid, v_grid = np.meshgrid(u, v)
E_analytic = (R + r*np.cos(v_grid))**2
G_analytic = np.full_like(E_analytic, r*r)

def gradient(f, dx, dy):
    df_du = (np.roll(f, -1, axis=1) - np.roll(f, 1, axis=1)) / (2*dx)
    df_dv = (np.roll(f, -1, axis=0) - np.roll(f, 1, axis=0)) / (2*dy)
    return df_du, df_dv

dE_du, dE_dv = gradient(E_analytic, du, dv)
dG_du, dG_dv = gradient(G_analytic, du, dv)

# Game state
generate_bump_hills(20)
# Compute maximum hill height for colormap normalization
max_hill = max(A for (_, _, A, _) in bump_hills) if bump_hills else 0.0
ball_u, ball_v = np.pi, np.pi
ball_du = ball_dv = 0.0
ball_active = False
hole_u, hole_v = random.uniform(0,2*math.pi), random.uniform(0,2*math.pi)
trail, max_trail_length = [], 150
angle_x, angle_y, zoom = 30, 30, -7.0
aim_angle, power = 0.0, 1.0

# Initialize Pygame & OpenGL
pygame.init(); glutInit()
screen = pygame.display.set_mode((800,600), DOUBLEBUF|OPENGL)
pygame.display.set_caption("Torus Golf - Tunable Geodesics")
clock = pygame.time.Clock()

glMatrixMode(GL_PROJECTION)
gluPerspective(45, 800/600, 0.1, 50.0)
glMatrixMode(GL_MODELVIEW)
glEnable(GL_DEPTH_TEST); glEnable(GL_LIGHTING); glEnable(GL_LIGHT0)
glEnable(GL_NORMALIZE); glEnable(GL_COLOR_MATERIAL)
glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE)
glLightModelfv(GL_LIGHT_MODEL_AMBIENT, (0.1,0.1,0.1,1))

# Import for colormap
import colorsys

# Compile torus mesh with height-based colormap
torus_list = glGenLists(1)
glNewList(torus_list, GL_COMPILE)
glBegin(GL_QUADS)
for i in range(res_u - 1):
    for j in range(res_v - 1):
        for di, dj in [(0,0),(0,1),(1,1),(1,0)]:
            u0, v0 = u[i+di], v[j+dj]
            pos, norm = torus_point_bumped(u0, v0)
            # compute visual bump height
            h_val = bump_height(u0, v0)
            # normalize height to [0,1]
            t = h_val / max_hill if max_hill > 0 else 0.0
            # map to color: green (low) to sandy yellow (high)
            # green hue ≈ 120°/360=0.333, yellow hue ≈ 45°/360=0.125
            hue_start = 0.3333
            hue_end = 0.125
            hue = hue_start + (hue_end - hue_start) * t
            rgb = colorsys.hsv_to_rgb(hue, 1.0, 1.0)
            glColor3f(*rgb)
            glNormal3f(*norm)
            glVertex3f(*pos)
glEnd()
glEndList()

pygame.font.init(); font = pygame.font.SysFont('Arial', 18); font=pygame.font.SysFont('Arial',18)

# Main loop
running=True
while running:
    clock.tick(60)
    for e in pygame.event.get():
        if e.type==QUIT: running=False
    keys=pygame.key.get_pressed()
    # Input
    if not ball_active:
        if keys[pygame.K_LEFT]: aim_angle+=0.05
        if keys[pygame.K_RIGHT]: aim_angle-=0.05
        if keys[pygame.K_UP]: power=min(power+0.05,3.0)
        if keys[pygame.K_DOWN]: power=max(power-0.05,0.1)
        if keys[pygame.K_SPACE]:
            ball_du=power*math.cos(aim_angle)
            ball_dv=power*math.sin(aim_angle)
            ball_active=True; trail=[(ball_u,ball_v)]
    # Camera
    if keys[pygame.K_w]: angle_x-=2
    if keys[pygame.K_s]: angle_x+=2
    if keys[pygame.K_a]: angle_y-=2
    if keys[pygame.K_d]: angle_y+=2
    if keys[pygame.K_EQUALS]: zoom+=0.1
    if keys[pygame.K_MINUS]: zoom-=0.1
    # Physics
    if ball_active:
        iu = int(ball_u/(2*math.pi)*res_u)%res_u
        iv = int(ball_v/(2*math.pi)*res_v)%res_v
        E_=E_analytic[iv,iu]; G_=G_analytic[iv,iu]
        a_u = (-0.5*dE_du[iv,iu]*ball_du**2 - 0.5*dG_du[iv,iu]*ball_dv**2)/E_
        a_v = (-0.5*dE_dv[iv,iu]*ball_du**2 - 0.5*dG_dv[iv,iu]*ball_dv**2)/G_
        # bump perturb
        eps=1e-4
        dh_du=(bump_height(ball_u+eps,ball_v)-bump_height(ball_u-eps,ball_v))/(2*eps)
        dh_dv=(bump_height(ball_u,ball_v+eps)-bump_height(ball_u,ball_v-eps))/(2*eps)
        g=np.array([dh_du,dh_dv]); v_vec=np.array([ball_du,ball_dv]); speed=np.linalg.norm(v_vec)
        if speed>1e-8:
            v_unit=v_vec/speed; perp=np.array([-v_unit[1],v_unit[0]])
            # perpendicular
            s_perp=np.dot(g,perp); a_perp=deflection_scale*s_perp*perp
            # parallel braking
            s_para=np.dot(g,v_unit); a_para=0.0
            if s_para>0: a_para=-brake_scale*s_para
            a_u+=a_perp[0]+a_para*v_unit[0]; a_v+=a_perp[1]+a_para*v_unit[1]
        # clamp & integrate
        speed=math.hypot(ball_du,ball_dv)
        if speed>max_speed: ball_du*=max_speed/speed; ball_dv*=max_speed/speed
        a_u=0.0 if not math.isfinite(a_u) else max(-max_accel,min(max_accel,a_u))
        a_v=0.0 if not math.isfinite(a_v) else max(-max_accel,min(max_accel,a_v))
        ball_du=(ball_du+a_u*dt)*drag; ball_dv=(ball_dv+a_v*dt)*drag
        ball_u=(ball_u+ball_du*dt)%(2*math.pi); ball_v=(ball_v+ball_dv*dt)%(2*math.pi)
        trail.append((ball_u,ball_v))
        if len(trail)>150: trail.pop(0)
        if math.hypot(ball_du,ball_dv)<stop_thresh: ball_active=False
        pb,_=torus_point_bumped(ball_u,ball_v); ph,_=torus_point_bumped(hole_u,hole_v)
        if np.linalg.norm(pb-ph)<0.1:
            hole_u, hole_v=random.uniform(0,2*math.pi),random.uniform(0,2*math.pi)
            ball_u, ball_v=random.uniform(0,2*math.pi),random.uniform(0,2*math.pi)
            ball_du=ball_dv=0.0; ball_active=False; trail=[]
    # Render
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT); glLoadIdentity()
    glTranslatef(0,0,zoom); glRotatef(angle_x,1,0,0); glRotatef(angle_y,0,1,0)
    glLightfv(GL_LIGHT0,GL_POSITION,(0,0,1,0)); glLightfv(GL_LIGHT0,GL_DIFFUSE,(0.9,0.8,0.6,1))
    glEnable(GL_LIGHT1); glLightfv(GL_LIGHT1,GL_POSITION,(8,0,0,1)); glLightfv(GL_LIGHT1,GL_DIFFUSE,(1,1,0.6,1)); glLightfv(GL_LIGHT1,GL_SPECULAR,(0.8,0.8,0.5,1))
    glPushMatrix(); glTranslatef(8,0,0); glColor3f(1,1,0.2); glutSolidSphere(0.3,20,20); glPopMatrix()
    ma=pygame.time.get_ticks()*0.0003; mx,mz=4*math.cos(ma),4*math.sin(ma)
    glPushMatrix(); glTranslatef(mx,0,mz); glColor3f(0.6,0.6,0.6); glutSolidSphere(0.15,20,20); glPopMatrix()
    glCallList(torus_list)
    pb,nb=torus_point_bumped(ball_u,ball_v); db=pb+nb*ball_offset
    glColor3f(1,0.2,0.2); glPointSize(8); glBegin(GL_POINTS); glVertex3f(*db); glEnd()
    if not ball_active:
        base,nrm=torus_point_bumped(ball_u,ball_v)
        tu=np.array([-(R+r*math.cos(ball_v))*math.sin(ball_u),(R+r*math.cos(ball_v))*math.cos(ball_u),0])
        tv=np.array([-r*math.sin(ball_v)*math.cos(ball_u),-r*math.sin(ball_v)*math.sin(ball_u),r*math.cos(ball_v)])
        dvv=np.cos(aim_angle)*tu+np.sin(aim_angle)*tv; dvv/=np.linalg.norm(dvv)
        st=base+nrm*ball_offset; tp=st+dvv*power*0.2
        glColor3f(1,1,0); glBegin(GL_LINES); glVertex3fv(st); glVertex3fv(tp); glEnd()
    ph,nh=torus_point_bumped(hole_u,hole_v); dh=ph+nh*ball_offset
    glColor3f(0,0.5,1); glPointSize(10); glBegin(GL_POINTS); glVertex3f(*dh); glEnd()
    glColor3f(1,0.5,0.3); glBegin(GL_LINE_STRIP)
    for tu0,vv0 in trail: p,n=torus_point_bumped(tu0,vv0); glVertex3f(*(p+n*ball_offset))
    glEnd()
    glDisable(GL_DEPTH_TEST)
    ov=pygame.Surface((800,600),pygame.SRCALPHA)
    t=font.render(f'P:{power:.2f} A:{np.degrees(aim_angle):.1f}°',True,(255,255,255))
    ov.blit(t,(600,10)); screen.blit(ov,(0,0)); glEnable(GL_DEPTH_TEST)
    pygame.display.flip()
pygame.quit()
