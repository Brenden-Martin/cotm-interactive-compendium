# Full 3D Torus Viewer with Ball Physics
# Dependencies: pygame, numpy, PyOpenGL

import numpy as np
import pygame
from pygame.locals import DOUBLEBUF, OPENGL, QUIT
from OpenGL.GL import *
from OpenGL.GLU import *

# Initialize Pygame and OpenGL
pygame.init()
screen = pygame.display.set_mode((800, 600), DOUBLEBUF | OPENGL)
pygame.display.set_caption("3D Torus Physics")
clock = pygame.time.Clock()

glMatrixMode(GL_PROJECTION)
gluPerspective(45, (800 / 600), 0.1, 50.0)
glMatrixMode(GL_MODELVIEW)
glEnable(GL_DEPTH_TEST)

# Torus parameters
R = 2.0
r = 0.6
res_u = 100
res_v = 50
u = np.linspace(0, 2 * np.pi, res_u)
v = np.linspace(0, 2 * np.pi, res_v)
u_grid, v_grid = np.meshgrid(u, v)

def torus_coords(u_val, v_val):
    x = (R + r * np.cos(v_val)) * np.cos(u_val)
    y = (R + r * np.cos(v_val)) * np.sin(u_val)
    z = r * np.sin(v_val)
    return np.array([x, y, z])

# Metric tensor for perfect torus
E = (R + r * np.cos(v_grid))**2
G = r**2 * np.ones_like(E)

# Gradient helper
def gradient(f, dx, dy):
    df_du = (np.roll(f, -1, axis=1) - np.roll(f, 1, axis=1)) / (2 * dx)
    df_dv = (np.roll(f, -1, axis=0) - np.roll(f, 1, axis=0)) / (2 * dy)
    return df_du, df_dv

du = u[1] - u[0]
dv = v[1] - v[0]
dE_du, dE_dv = gradient(E, du, dv)
dG_du, dG_dv = gradient(G, du, dv)

# Ball state
ball_u = np.pi
ball_v = np.pi
ball_du = 0.0
ball_dv = 0.0
ball_active = False
trail = []

drag = 0.995
dt = 0.02
stop_threshold = 0.01

# View state
angle_x, angle_y = 30, 30
zoom = -7.0

# Shot control
aim_angle = 0.0
power = 1.0

# Font setup for UI overlay
pygame.font.init()
font = pygame.font.SysFont('Arial', 18)

running = True
while running:
    clock.tick(60)
    for event in pygame.event.get():
        if event.type == QUIT:
            running = False

    keys = pygame.key.get_pressed()
    if not ball_active:
        if keys[pygame.K_LEFT]:
            aim_angle += 0.05
        if keys[pygame.K_RIGHT]:
            aim_angle -= 0.05
        if keys[pygame.K_UP]:
            power = min(power + 0.05, 5.0)
        if keys[pygame.K_DOWN]:
            power = max(power - 0.05, 0.1)
        if keys[pygame.K_SPACE]:
            ball_du = power * np.cos(aim_angle) / (R + r * np.cos(ball_v))  # normalize for E
            ball_dv = power * np.sin(aim_angle) / r  # normalize for G
            ball_active = True
            trail = [(ball_u, ball_v)]

    if keys[pygame.K_w]: angle_x -= 2
    if keys[pygame.K_s]: angle_x += 2
    if keys[pygame.K_a]: angle_y -= 2
    if keys[pygame.K_d]: angle_y += 2
    if keys[pygame.K_EQUALS]: zoom += 0.1
    if keys[pygame.K_MINUS]: zoom -= 0.1

    if ball_active:
        idx_u = int((ball_u / (2 * np.pi)) * res_u) % res_u
        idx_v = int((ball_v / (2 * np.pi)) * res_v) % res_v
        E_ = E[idx_v, idx_u]
        G_ = G[idx_v, idx_u]
        dE_du_ = dE_du[idx_v, idx_u]
        dE_dv_ = dE_dv[idx_v, idx_u]
        dG_du_ = dG_du[idx_v, idx_u]
        dG_dv_ = dG_dv[idx_v, idx_u]

        a_u = (-0.5 * dE_du_ * ball_du**2 - 0.5 * dG_du_ * ball_dv**2) / E_
        a_v = (-0.5 * dE_dv_ * ball_du**2 - 0.5 * dG_dv_ * ball_dv**2) / G_

        ball_du = (ball_du + a_u * dt) * drag
        ball_dv = (ball_dv + a_v * dt) * drag
        ball_u = (ball_u + ball_du * dt) % (2 * np.pi)
        ball_v = (ball_v + ball_dv * dt) % (2 * np.pi)
        trail.append((ball_u, ball_v))

        if np.hypot(ball_du, ball_dv) < stop_threshold:
            ball_active = False

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glLoadIdentity()
    glTranslatef(0.0, 0.0, zoom)
    glRotatef(angle_x, 1, 0, 0)
    glRotatef(angle_y, 0, 1, 0)

    glBegin(GL_QUADS)
    for i in range(res_u - 1):
        for j in range(res_v - 1):
            for di, dj in [(0, 0), (0, 1), (1, 1), (1, 0)]:
                u_val = u[i + di]
                v_val = v[j + dj]
                x, y, z = torus_coords(u_val, v_val)
                glColor3f(0.3 + 0.3 * np.cos(z), 0.7, 0.4)
                glVertex3f(x, y, z)
    glEnd()

    # Draw ball
    bx, by, bz = torus_coords(ball_u, ball_v)
    glColor3f(1.0, 0.2, 0.2)
    glPointSize(8.0)
    glBegin(GL_POINTS)
    glVertex3f(bx, by, bz)
    glEnd()

    # Draw aim vector in 3D (if ball is not active)
    if not ball_active:
        aim_du = power * np.cos(aim_angle) / (R + r * np.cos(ball_v))
        aim_dv = power * np.sin(aim_angle) / r
        offset_u = (ball_u + aim_du * 0.2) % (2 * np.pi)
        offset_v = (ball_v + aim_dv * 0.2) % (2 * np.pi)
        ax, ay, az = torus_coords(offset_u, offset_v)
        glColor3f(1.0, 1.0, 0.0)
        glBegin(GL_LINES)
        glVertex3f(bx, by, bz)
        glVertex3f(ax, ay, az)
        glEnd()

    # Draw trail
    glColor3f(1.0, 0.5, 0.3)
    glBegin(GL_LINE_STRIP)
    for tu, tv in trail:
        tx, ty, tz = torus_coords(tu, tv)
        glVertex3f(tx, ty, tz)
    glEnd()

        # Render UI overlay
    glDisable(GL_DEPTH_TEST)  # Allow 2D overlay
    overlay = pygame.Surface((800, 600), pygame.SRCALPHA)
    text = font.render(f'Power: {power:.2f}  Angle: {np.degrees(aim_angle):.1f}°', True, (255, 255, 255))
    overlay.blit(text, (600, 10))
    screen.blit(overlay, (0, 0))
    glEnable(GL_DEPTH_TEST)

    pygame.display.flip()

pygame.quit()
