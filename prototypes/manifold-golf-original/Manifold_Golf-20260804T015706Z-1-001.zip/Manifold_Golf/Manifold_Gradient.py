import pygame
import numpy as np
import sys

# Initialize pygame
pygame.init()
screen_size = (640, 480)
screen = pygame.display.set_mode(screen_size)
pygame.display.set_caption("Manifold Golf: Torus Geodesic Physics")
clock = pygame.time.Clock()

# UV Grid Setup
res = 100
u = np.linspace(0, 2 * np.pi, res)
v = np.linspace(0, 2 * np.pi, res)
du = u[1] - u[0]
dv = v[1] - v[0]
u_grid, v_grid = np.meshgrid(u, v)

# Torus parameters
R = 2.0
r = 0.6

# Compute metric tensor components for a perfect torus
E = (R + r * np.cos(v_grid))**2
F = np.zeros_like(E)
G = r**2 * np.ones_like(E)

# Derivatives of metric tensor
def gradient(f, dx, dy):
    df_du = (np.roll(f, -1, axis=1) - np.roll(f, 1, axis=1)) / (2 * dx)
    df_dv = (np.roll(f, -1, axis=0) - np.roll(f, 1, axis=0)) / (2 * dy)
    return df_du, df_dv

dE_du, dE_dv = gradient(E, du, dv)
dF_du, dF_dv = gradient(F, du, dv)
dG_du, dG_dv = gradient(G, du, dv)

# Ball state
ball_u = np.pi
ball_v = np.pi
ball_du = 0.0
ball_dv = 0.0
ball_active = False

# Shot selection
aim_angle = 0.0
power = 1.0

# Colors
BG_COLOR = (10, 10, 40)
BALL_COLOR = (255, 80, 80)
VECTOR_COLOR = (120, 120, 255)

# Physics
drag = 0.995
dt = 0.02
stop_threshold = 0.01  # Higher than before

# Mapping UV to screen
def to_screen_coords(u, v):
    x = int((u / (2 * np.pi)) * screen_size[0])
    y = int((v / (2 * np.pi)) * screen_size[1])
    return x, y

def draw_course_with_vectors():
    screen.fill(BG_COLOR)
    step = 10  # Vector field downsampling
    for i in range(0, res, step):
        for j in range(0, res, step):
            ui = u_grid[i, j]
            vi = v_grid[i, j]
            E_, F_, G_ = E[i, j], F[i, j], G[i, j]
            dE_du_, dE_dv_ = dE_du[i, j], dE_dv[i, j]
            dF_du_, dF_dv_ = dF_du[i, j], dF_dv[i, j]
            dG_du_, dG_dv_ = dG_du[i, j], dG_dv[i, j]
            
            # Small test velocity for vector field
            du_test, dv_test = 1.0, 0.0

            # Acceleration from geodesic equation (no Christoffel symbols used directly)
            a_u = (-0.5 * dE_du_ * du_test**2 - dF_du_ * du_test * dv_test - 0.5 * dG_du_ * dv_test**2) / E_
            a_v = (-0.5 * dE_dv_ * du_test**2 - dF_dv_ * du_test * dv_test - 0.5 * dG_dv_ * dv_test**2) / G_

            x, y = to_screen_coords(ui, vi)
            dx = int(10 * a_u)
            dy = int(10 * a_v)
            pygame.draw.line(screen, VECTOR_COLOR, (x, y), (x + dx, y + dy), 1)

def draw_ball(u, v):
    x, y = to_screen_coords(u, v)
    pygame.draw.circle(screen, BALL_COLOR, (x, y), 6)

# Main loop
running = True
while running:
    clock.tick(60)
    draw_course_with_vectors()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    if not ball_active:
        if keys[pygame.K_LEFT]:
            aim_angle -= 0.05
        if keys[pygame.K_RIGHT]:
            aim_angle += 0.05
        if keys[pygame.K_UP]:
            power = min(power + 0.05, 5.0)
        if keys[pygame.K_DOWN]:
            power = max(power - 0.05, 0.1)
        if keys[pygame.K_SPACE]:
            ball_du = power * np.cos(aim_angle)
            ball_dv = power * np.sin(aim_angle)
            ball_active = True

    if ball_active:
        # Ball UV to grid indices
        idx_u = int((ball_u / (2 * np.pi)) * res) % res
        idx_v = int((ball_v / (2 * np.pi)) * res) % res

        E_, F_, G_ = E[idx_v, idx_u], F[idx_v, idx_u], G[idx_v, idx_u]
        dE_du_, dE_dv_ = dE_du[idx_v, idx_u], dE_dv[idx_v, idx_u]
        dF_du_, dF_dv_ = dF_du[idx_v, idx_u], dF_dv[idx_v, idx_u]
        dG_du_, dG_dv_ = dG_du[idx_v, idx_u], dG_dv[idx_v, idx_u]

        # Acceleration
        a_u = (-0.5 * dE_du_ * ball_du**2 - dF_du_ * ball_du * ball_dv - 0.5 * dG_du_ * ball_dv**2) / E_
        a_v = (-0.5 * dE_dv_ * ball_du**2 - dF_dv_ * ball_du * ball_dv - 0.5 * dG_dv_ * ball_dv**2) / G_

        # Update velocity and position
        ball_du = (ball_du + a_u * dt) * drag
        ball_dv = (ball_dv + a_v * dt) * drag
        ball_u = (ball_u + ball_du * dt) % (2 * np.pi)
        ball_v = (ball_v + ball_dv * dt) % (2 * np.pi)

        if np.hypot(ball_du, ball_dv) < stop_threshold:
            ball_active = False

    draw_ball(ball_u, ball_v)

    if not ball_active:
        cx, cy = to_screen_coords(ball_u, ball_v)
        dx = int(30 * power * np.cos(aim_angle))
        dy = int(30 * power * np.sin(aim_angle))
        pygame.draw.line(screen, (255, 255, 0), (cx, cy), (cx + dx, cy + dy), 2)

    pygame.display.flip()

pygame.quit()
sys.exit()

