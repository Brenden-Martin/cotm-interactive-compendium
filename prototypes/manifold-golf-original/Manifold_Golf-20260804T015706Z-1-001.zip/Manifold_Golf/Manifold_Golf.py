import pygame
import numpy as np
import sys

# Initialize pygame
pygame.init()
screen_size = (640, 480)
screen = pygame.display.set_mode(screen_size)
pygame.display.set_caption("Manifold Golf: UV Geodesic Putter")
clock = pygame.time.Clock()

# Grid setup
res = 200
u = np.linspace(0, 2 * np.pi, res)
v = np.linspace(0, 2 * np.pi, res)
du = u[1] - u[0]
dv = v[1] - v[0]
u_grid, v_grid = np.meshgrid(u, v)

# Ball state
ball_u = np.pi
ball_v = np.pi
ball_du = 0.0
ball_dv = 0.0
ball_active = False

# Shot selection
aim_angle = 0.0
power = 1.0

# Colors
BG_COLOR = (10, 10, 40)
BALL_COLOR = (255, 80, 80)
TERRAIN_COLOR = (50, 150, 80)

# Geodesic simulation parameters
drag = 0.995
dt = 0.02

def to_screen_coords(u, v):
    """Map (u,v) in [0,2pi] to screen coords"""
    x = int((u / (2 * np.pi)) * screen_size[0])
    y = int((v / (2 * np.pi)) * screen_size[1])
    return x, y

def draw_course():
    """Draw UV grid"""
    screen.fill(BG_COLOR)
    for i in range(0, res, 6):
        for j in range(0, res, 6):
            x, y = to_screen_coords(u_grid[i, j], v_grid[i, j])
            pygame.draw.circle(screen, TERRAIN_COLOR, (x, y), 1)

def draw_ball(u, v):
    x, y = to_screen_coords(u, v)
    pygame.draw.circle(screen, BALL_COLOR, (x, y), 6)

# Main loop
running = True
while running:
    clock.tick(60)
    draw_course()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    if not ball_active:
        if keys[pygame.K_LEFT]:
            aim_angle -= 0.05
        if keys[pygame.K_RIGHT]:
            aim_angle += 0.05
        if keys[pygame.K_UP]:
            power = min(power + 0.05, 5.0)
        if keys[pygame.K_DOWN]:
            power = max(power - 0.05, 0.1)
        if keys[pygame.K_SPACE]:
            ball_du = power * np.cos(aim_angle)
            ball_dv = power * np.sin(aim_angle)
            ball_active = True

    if ball_active:
        ball_u = (ball_u + ball_du * dt) % (2 * np.pi)
        ball_v = (ball_v + ball_dv * dt) % (2 * np.pi)
        ball_du *= drag
        ball_dv *= drag
        if np.hypot(ball_du, ball_dv) < 0.001:
            ball_active = False

    draw_ball(ball_u, ball_v)

    if not ball_active:
        cx, cy = to_screen_coords(ball_u, ball_v)
        dx = int(30 * power * np.cos(aim_angle))
        dy = int(30 * power * np.sin(aim_angle))
        pygame.draw.line(screen, (255, 255, 0), (cx, cy), (cx + dx, cy + dy), 2)

    pygame.display.flip()

pygame.quit()
sys.exit()
