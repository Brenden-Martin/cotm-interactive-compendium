import numpy as np
import pygame
from pygame.locals import DOUBLEBUF, OPENGL
from OpenGL.GL import *
from OpenGL.GLU import *

# Initialize Pygame and OpenGL
pygame.init()
screen = pygame.display.set_mode((800, 600), DOUBLEBUF | OPENGL)
pygame.display.set_caption("3D Torus Viewer")

glMatrixMode(GL_PROJECTION)
gluPerspective(45, (800 / 600), 0.1, 50.0)
glMatrixMode(GL_MODELVIEW)
glEnable(GL_DEPTH_TEST)

R = 2.0
r = 0.6
res_u = 60
res_v = 30
u = np.linspace(0, 2 * np.pi, res_u)
v = np.linspace(0, 2 * np.pi, res_v)
u_grid, v_grid = np.meshgrid(u, v)
x = (R + r * np.cos(v_grid)) * np.cos(u_grid)
y = (R + r * np.cos(v_grid)) * np.sin(u_grid)
z = r * np.sin(v_grid)
vertices = np.stack([x, y, z], axis=-1)

angle_x, angle_y = 30, 30
zoom = -7
clock = pygame.time.Clock()

running = True
while running:
    clock.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]: angle_y -= 2
    if keys[pygame.K_RIGHT]: angle_y += 2
    if keys[pygame.K_UP]: angle_x -= 2
    if keys[pygame.K_DOWN]: angle_x += 2
    if keys[pygame.K_w]: zoom += 0.1
    if keys[pygame.K_s]: zoom -= 0.1

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glLoadIdentity()
    glTranslatef(0.0, 0.0, zoom)
    glRotatef(angle_x, 1, 0, 0)
    glRotatef(angle_y, 0, 1, 0)

    glBegin(GL_QUADS)
    for i in range(res_u - 1):
        for j in range(res_v - 1):
            for di, dj in [(0, 0), (0, 1), (1, 1), (1, 0)]:
                vtx = vertices[j + dj, i + di]
                glColor3f(0.3 + 0.3 * np.cos(vtx[2]), 0.7, 0.4)
                glVertex3fv(vtx)
    glEnd()

    pygame.display.flip()

pygame.quit()
